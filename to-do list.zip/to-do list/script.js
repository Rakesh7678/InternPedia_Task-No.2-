const pendingTasksList = document.getElementById("pending-tasks");
const completedTasksList = document.getElementById("completed-tasks");
const addTaskBtn = document.getElementById("add-task-btn");
const newTaskInput = document.getElementById("new-task");
const clearTasksBtn = document.getElementById("clear-tasks-btn");

let tasks = []; // Array to store tasks

function addTask() {
  const newTask = newTaskInput.value.trim(); // Trim whitespace from input
  if (newTask) {
    tasks.push({ text: newTask, completed: false });
    updateTasksList();
    newTaskInput.value = ""; // Clear input field after adding task
  }
}

function updateTasksList() {
  pendingTasksList.innerHTML = ""; // Clear existing tasks before update
  completedTasksList.innerHTML = "";

  tasks.forEach((task) => {
    const listItem = document.createElement("li");
    listItem.innerText = task.text;
    listItem.addEventListener("click", function () {
      task.completed = !task.completed; // Toggle completion status
      updateTasksList();
    });

    if (task.completed) {
      listItem.classList.add("completed");
      completedTasksList.appendChild(listItem);
    } else {
      pendingTasksList.appendChild(listItem);
    }
  });
}

function clearAllTasks() {
  // Confirmation before clearing tasks (optional)
  if (confirm("Are you sure you want to clear all tasks?")) {
    tasks = []; // Clear the tasks array
    updateTasksList();
  }
}

addTaskBtn.addEventListener("click", addTask);

clearTasksBtn.addEventListener("click", clearAllTasks);

// Load tasks from localStorage if available
window.onload = function () {
  const storedTasks = localStorage.getItem("tasks");
  if (storedTasks) {
    tasks = JSON.parse(storedTasks);
  }
  updateTasksList();
};

// Save tasks to localStorage on any change
window.onbeforeunload = function () {
  localStorage.setItem("tasks", JSON.stringify(tasks));
};
